export { auth, db, storage, app } from './config';
export * from 'firebase/auth';
export * from 'firebase/firestore';
export * from 'firebase/storage';
